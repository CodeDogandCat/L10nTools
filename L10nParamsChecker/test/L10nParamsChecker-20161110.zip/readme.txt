﻿
1.如果在default存在，在other中不存在，则忽略

2.Mac/iOS的字符串的name中可能有通配符，无法检查。
     
3. 假定default文件为正确的的规范的，如果  default 中不满足下列条件的参数，忽略 
android:
	%% 认为是%的转义，不比较
	%s
	%d
	%f
	%.【2到9】f
	%【1到9】$【s 或 d 或 .【2到9】f】
	有$ 的参数用contain


windows:
	%% 认为是%的转义，不比较
	%s
	%d
	%f
	%.【2到9】f


ios/mac:
    %% 认为是%的转义，不比较
	%s
	%d
	%@
	%qu
	%f
	%.【2到9】f
    增加 %u
